/*
 * Machine-reconstructed pseudocode; not original vendor source.
 * Mach-O extent: 0xc64e7c..0xc64eb0 (52 bytes).
 * Function and variable names are synthetic unless documented elsewhere.
 */


void sub_c64e7c(void)
{
    unsigned long long v5;  // x20
    unsigned long long v6;  // x19
    unsigned long long v7;  // x30
    unsigned long long v0;  // [bp-0x20]
    unsigned long long v1;  // [bp-0x18]
    char *v2;  // [bp-0x10]
    unsigned long long v3;  // [bp-0x8]
    char v4;  // [bp+0x0]

    v0 = v5;
    v1 = v6;
    v2 = &v4;
    v3 = v7;
    sub_996e70();
    sub_996e50(sub_a369bc("ssl/record/methods/tls1_meth.c", 195, "tls1_cipher"), 195, "tls1_cipher");
}
