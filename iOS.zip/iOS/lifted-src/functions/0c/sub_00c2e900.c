/*
 * Machine-reconstructed pseudocode; not original vendor source.
 * Mach-O extent: 0xc2e900..0xc2f680 (3456 bytes).
 * Function and variable names are synthetic unless documented elsewhere.
 */

typedef struct st_c2e900_2 {
    char padding_0[8];
    struct st_c2e900_1 *field_8;
} st_c2e900_2;

typedef struct st_c2e900_1 {
    char padding_0[24];
    struct st_c2e900_0 *field_18;
} st_c2e900_1;

typedef struct st_c2e900_0 {
    unsigned long long field_0;
} st_c2e900_0;


void sub_c2e900(st_c2e900_0 **a0, st_c2e900_2 *a1)
{
    unsigned long long v9;  // x24
    unsigned long long v10;  // x23
    unsigned long long v11;  // x22
    unsigned long long v12;  // x21
    unsigned long long v13;  // x20
    unsigned long long v14;  // x19
    unsigned long long v15;  // x30
    unsigned long long v16;  // x8
    unsigned long long v17;  // 4163
    unsigned long long v0;  // [bp-0x40]
    unsigned long long v1;  // [bp-0x38]
    unsigned long long v2;  // [bp-0x30]
    unsigned long long v3;  // [bp-0x28]
    unsigned long long v4;  // [bp-0x20]
    unsigned long long v5;  // [bp-0x18]
    char *v6;  // [bp-0x10]
    unsigned long long v7;  // [bp-0x8]
    char v8;  // [bp+0x0]

    v0 = v9;
    v1 = v10;
    v2 = v11;
    v3 = v12;
    v4 = v13;
    v5 = v14;
    v6 = &v8;
    v7 = v15;
    v16 = 2;
    v17 = arm64g_calculate_condition(0x44, *(long long *)*a0, 0, 0);
    if (v17 & 1)
        v16 = *(long long *)*a0 ^ 0x8000000000000000;
    if (!v16)
    {
        a1->field_8->field_18();
    }
    else if (v16 == 1)
    {
        a1->field_8->field_18();
    }
    else
    {
        a1->field_8->field_18();
    }
}
